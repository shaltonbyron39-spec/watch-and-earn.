# Watch & Earn — secure backend starter

This starter lays the foundation for real accounts, a reward ledger, video tasks, and M-PESA withdrawal requests.

## Important status
- This is a development starter, not a production payment system.
- No real rewards are credited by the demo website.
- Never ask members to deposit money to unlock withdrawals.
- Only credit rewards after a trusted sponsor/ad provider confirms an eligible task server-to-server.
- Keep all Supabase service-role keys and Safaricom Daraja secrets on a trusted server/Edge Function. Never put them in browser JavaScript.
- M-PESA production payouts require Safaricom approval and a suitable B2C/one-account shortcode.

## Files
- `supabase/schema.sql`: database tables, signup profile trigger, and row-level security policies.
- `docs/BUILD_STEPS.md`: phone-friendly setup sequence.
- `docs/REWARDS_AND_PAYMENTS.md`: safe rules for earning and M-PESA payouts.

## Suggested stack
- Supabase Auth + Postgres for accounts and records.
- A server-side function (Supabase Edge Function or another trusted backend) for reward verification and Daraja API calls.
- A commercial hosting plan suitable for a business website.
- A domain registered when you're ready.

## Do not launch payments until
1. Business identity and Safaricom business payment arrangements are approved.
2. A real sponsor has funded the reward budget.
3. Terms, privacy notice, support contact, eligibility rules, and withdrawal fees/minimums (if any) are published clearly.
4. Server-side verification, rate limits, audit logs, admin controls, and payment reconciliation are tested.
5. Daraja sandbox tests pass, then Safaricom production approval is obtained.
