# Rewards and M-PESA safeguards

## Reward funding
Each video task must have a real sponsor/advertiser agreement and a funded reward budget. Do not promise a fixed income or pay for views unless the content provider explicitly permits incentivized viewing.

## Completion verification
A browser timer alone is not proof that a video was watched. Use a sponsor/provider's permitted server-to-server completion signal or another contractually approved verification method. Enforce one reward per eligible user/task/campaign, replay protection, rate limits, and fraud review.

## Wallet
Treat the ledger as the source of truth. Do not store an editable balance field as the authority. Ledger entries should be written only by trusted server-side code, with unique references and atomic database transactions.

## Withdrawal lifecycle
1. Member requests withdrawal.
2. Server validates identity/phone, minimum amount, available ledger balance, account status, and risk checks.
3. Server reserves funds atomically and creates an auditable request.
4. Admin reviews it.
5. Approved payout is sent through Daraja B2C from a server-side function.
6. The system waits for Safaricom callback and records the receipt/status.
7. Failed or rejected payouts release the reservation safely; never mark a payout paid merely because the API accepted the request.

## Security
- Never expose Supabase service-role keys or Daraja credentials in frontend code.
- Use HTTPS, access controls, audit logs, backups, rate limits, and monitoring.
- Require admin MFA and separate initiator/approver roles where available.
- Publish terms, privacy policy, eligibility, withdrawal threshold, expected processing times, fees (if any), and support details.
- Do not ask users to pay a deposit to unlock an earned balance.
