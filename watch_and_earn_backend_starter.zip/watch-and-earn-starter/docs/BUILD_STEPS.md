# Build steps from an Android phone

1. Open the Supabase website in Chrome and create an account.
2. Create a project named `watch-and-earn-dev`. Save the database password privately; do not send it in chat.
3. Open the project's SQL Editor, create a new query, paste `supabase/schema.sql`, and run it.
4. In Authentication settings, configure the sign-in method you want (email/password is a straightforward first version). Set the site URL and allowed redirect URLs when a hosted app exists.
5. Keep the project in development. Test creating a member account and confirm a profile row appears.
6. Add the frontend to a GitHub repository. You can use GitHub in Chrome; for editing larger files, a browser-based development environment may be easier.
7. Connect the repository to a business-appropriate hosting plan. Check current commercial-use terms before choosing a free tier.
8. Build server-side functions for:
   - creating a watch session;
   - receiving trusted sponsor/provider completion callbacks;
   - validating duplicate/fraudulent completions;
   - atomically writing a reward ledger entry;
   - requesting a withdrawal and reserving the balance;
   - sending B2C payouts only after admin approval;
   - processing Safaricom result/timeout callbacks and reconciling receipts.
9. Test all payment flows in Daraja sandbox. Do not use live customer funds during testing.
10. Buy/connect the domain only after the basic app and policies are ready.

Never paste API secrets, passwords, M-PESA PINs, one-time passwords, or identity documents into ChatGPT or public code repositories.
