-- Watch & Earn database starter (Supabase/Postgres)
-- Run in a NEW development project first. Review before production.

create extension if not exists pgcrypto;

create type public.app_role as enum ('member', 'admin');
create type public.task_status as enum ('draft', 'active', 'paused');
create type public.watch_status as enum ('started', 'verified', 'rejected');
create type public.ledger_kind as enum ('reward', 'adjustment', 'withdrawal_hold', 'withdrawal_release', 'withdrawal_paid');
create type public.withdrawal_status as enum ('requested', 'under_review', 'approved', 'processing', 'paid', 'rejected', 'failed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone_e164 text unique,
  role public.app_role not null default 'member',
  created_at timestamptz not null default now()
);

create table public.video_tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  video_url text not null,
  sponsor_name text,
  reward_kes numeric(12,2) not null check (reward_kes > 0),
  duration_seconds integer not null check (duration_seconds > 0),
  status public.task_status not null default 'draft',
  created_at timestamptz not null default now()
);

create table public.watch_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  task_id uuid not null references public.video_tasks(id),
  status public.watch_status not null default 'started',
  started_at timestamptz not null default now(),
  verified_at timestamptz,
  provider_reference text unique,
  rejection_reason text
);

-- Append-only wallet ledger. Do not allow members to insert/update/delete rows.
create table public.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind public.ledger_kind not null,
  amount_kes numeric(12,2) not null check (amount_kes <> 0),
  reference text unique,
  description text,
  created_at timestamptz not null default now()
);

create table public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount_kes numeric(12,2) not null check (amount_kes > 0),
  mpesa_phone_e164 text not null,
  status public.withdrawal_status not null default 'requested',
  idempotency_key uuid not null default gen_random_uuid(),
  safaricom_receipt text unique,
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, idempotency_key)
);

create index watch_sessions_user_task_idx on public.watch_sessions(user_id, task_id);
create index ledger_user_created_idx on public.wallet_ledger(user_id, created_at desc);
create index withdrawals_user_created_idx on public.withdrawal_requests(user_id, created_at desc);

-- Create a profile automatically when a new Auth user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''));
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.video_tasks enable row level security;
alter table public.watch_sessions enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;

-- Members can read/update only their own basic profile; role is not user-editable.
create policy "profile_select_own" on public.profiles
for select to authenticated using (auth.uid() = id);

create policy "profile_update_own" on public.profiles
for update to authenticated using (auth.uid() = id)
with check (auth.uid() = id and role = 'member');

-- Authenticated users can see active tasks.
create policy "active_tasks_read" on public.video_tasks
for select to authenticated using (status = 'active');

-- Members can create/read their own watch session records.
-- IMPORTANT: trusted verification must be done by server-side code; clients must not set verified.
create policy "watch_sessions_read_own" on public.watch_sessions
for select to authenticated using (auth.uid() = user_id);

create policy "watch_sessions_insert_own" on public.watch_sessions
for insert to authenticated with check (auth.uid() = user_id and status = 'started');

-- Members can read their own ledger; no client write policies are provided.
create policy "ledger_read_own" on public.wallet_ledger
for select to authenticated using (auth.uid() = user_id);

-- Members can read their own withdrawal requests and submit requests.
-- Server-side code must validate balance, reserve funds atomically, and enforce limits.
create policy "withdrawals_read_own" on public.withdrawal_requests
for select to authenticated using (auth.uid() = user_id);

create policy "withdrawals_insert_own" on public.withdrawal_requests
for insert to authenticated with check (
  auth.uid() = user_id and status = 'requested'
);

-- No member-facing update/delete policies for ledger or withdrawal requests.
-- Admin/service operations must run on a trusted backend with proper authorization.
